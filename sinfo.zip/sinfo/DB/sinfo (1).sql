-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 10, 2023 at 07:02 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sinfo`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(2, 'admin', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL,
  `venue` varchar(100) NOT NULL,
  `scheduredate` varchar(100) NOT NULL,
  `scheduretime` varchar(100) NOT NULL,
  `deleted` int(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `title`, `description`, `venue`, `scheduredate`, `scheduretime`, `deleted`) VALUES
(1, 'Public Lecture', 'More Info on this event', 'Multi-Hall', '2022-11-30', '15:00', 0),
(2, 'Kwiga', 'Kwiga', 'Huye', '2022-11-14', '18:23', 0);

-- --------------------------------------------------------

--
-- Table structure for table `marks`
--

CREATE TABLE `marks` (
  `id` int(11) NOT NULL,
  `student` varchar(100) NOT NULL,
  `course` varchar(100) NOT NULL,
  `sem` varchar(100) NOT NULL,
  `value` varchar(100) NOT NULL,
  `deleted` int(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `marks`
--

INSERT INTO `marks` (`id`, `student`, `course`, `sem`, `value`, `deleted`) VALUES
(2, '19rp09180', 'Networking', 'II', '50', 0),
(3, '19RP05600', 'Networking', 'II', '40', 1);

-- --------------------------------------------------------

--
-- Table structure for table `requests`
--

CREATE TABLE `requests` (
  `id` int(11) NOT NULL,
  `student` varchar(100) NOT NULL,
  `status` int(1) NOT NULL DEFAULT 0,
  `rdatetime` varchar(100) NOT NULL,
  `refid` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `requests`
--

INSERT INTO `requests` (`id`, `student`, `status`, `rdatetime`, `refid`) VALUES
(5, '3', 1, '1669600150', '16696001521364'),
(6, '9', 0, '1669617175', '16696171772499'),
(7, '9', 0, '1669617481', '16696174839161'),
(8, '9', 1, '1669618173', '16696181753265'),
(9, '6', 0, '1669619219', '16696192226376'),
(10, '6', 0, '1669619241', '16696192432280'),
(11, '11', 0, '1669984180', '16699841824816'),
(12, '6', 0, '1670184328', '16701843304216'),
(13, '2', 0, '1670223074', '16702230742473');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(11) NOT NULL,
  `regno` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `class` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `image` varchar(100) NOT NULL,
  `deleted` int(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `regno`, `name`, `phone`, `email`, `class`, `password`, `image`, `deleted`) VALUES
(3, '18RP00946', 'Melchi Roger', '0788620994', 'melchiroger@gmail.com', 'LEVEL 2 IT', 'm123', 'images/1669558550.png', 1),
(4, '19RP05600', 'Muhire Ivan Sebastien', '0782881173', 'sebastienmuhire@gmail.com', 'ICT l3b', '1234', 'images/1669563009.png', 1),
(5, '19RP05600', 'Muhire Ivan Sebastien', '0782881173', 'sebastienmuhire@gmail.com', 'ICT L3B', '123', 'images/1669569786.png', 1),
(6, '19rp09180', 'GATAMBARA Yves', '0782814895', 'nikunta9@gmail.com', 'L3B', 'kunta', 'images/1669570001.png', 0),
(7, '19Rp0345', 'Ishimwe Gaston ', '0781680778', 'gastonsevanni@gmail.com', 'L2B', 'gaston1234', 'images/1669572715.png', 1),
(8, '19RP8967', 'Ajika Gandhi', '0780803000', 'ajikagandhi1999@gmail.com', 'L1B', 'ajika', 'images/1669572997.png', 1),
(9, '19RP00230', 'Muhire Ivan Sebastien', '0782881173', 'seba@gmail.com', 'L3', '12345', 'images/1669578659.png', 1),
(10, '19RP05600', 'Muhire Ivan Sebastien', '0782881173', 'seba@gmail.com', 'IT 2', '12345', 'images/1669618072.png', 1),
(11, '19RP10360', 'Parfait', '0788905880', 'parfaitpaccyg70@gmail.com', 'ICT L3A', 'paccy', 'images/1669984032.png', 0),
(12, '19RP09999', 'Bwiza', '0788752773', 'bwiza@gmail.com', 'ICT L3', '1234', 'images/1669991497.png', 1),
(13, '19RP09999', 'Bwiza', '0788752773', 'bwiza@gmail.com', 'ICT L3', '1234', 'images/1669991500.png', 1),
(14, '19RP07767', 'Ganza Rene', '0786657744', 'ganza@gmail.com', 'Civil l3', '1234', 'images/1669999957.png', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `marks`
--
ALTER TABLE `marks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `requests`
--
ALTER TABLE `requests`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`),
  ADD KEY `deleted` (`deleted`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `marks`
--
ALTER TABLE `marks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `requests`
--
ALTER TABLE `requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
