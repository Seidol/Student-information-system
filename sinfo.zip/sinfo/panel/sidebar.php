<nav class="sidebar sidebar-offcanvas" id="sidebar">
        <ul class="nav">
          <li class="nav-item">
            <a class="nav-link" href="index.php">
              <i class="typcn typcn-device-desktop menu-icon"></i>
              <span class="menu-title">Dashboard</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="companies.php">
              <i class="typcn typcn-user menu-icon"></i>
              <span class="menu-title">Students</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="events.php">
              <i class="typcn typcn-clipboard menu-icon"></i>
              <span class="menu-title">Events</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="marks.php">
              <i class="typcn typcn-clipboard menu-icon"></i>
              <span class="menu-title">Marks</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="requests.php">
              <i class="typcn typcn-user menu-icon"></i>
              <span class="menu-title">Cards Requests</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="../login.php">
              <i class="typcn typcn-mortar-board menu-icon"></i>
              <span class="menu-title">Logout</span>
            </a>
          </li>
        </ul>
      </nav>