<?php session_start(); unset($_SESSION['dds_user']); ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <!-- base:css -->
  <link rel="stylesheet" href="panel/vendors/typicons/typicons.css">
  <link rel="stylesheet" href="panel/vendors/css/vendor.bundle.base.css">
  <!-- endinject -->
  <!-- plugin css for this page -->
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="panel/css/vertical-layout-light/style.css">
  <!-- endinject -->
</head>

<body>
  <div class="container-scroller">
    <div class="container-fluid page-body-wrapper full-page-wrapper">
      <div class="content-wrapper d-flex align-items-center auth px-0">
        <div class="row w-100 mx-0">
          <div class="col-lg-4 mx-auto">
            <div class="auth-form-light text-left py-5 px-4 px-sm-5">
              <h4>Sign in to continue</h4>
              <!-- <h6 class="font-weight-light">Sign in to continue</h6> -->
              <form class="pt-3" method="POST" action="server.php">

                <?php
                    if(isset($_GET['error']) AND $_GET['error'] == 'invalid'){
                        echo"<div class='alert alert-danger text-center' role='alert'>
                          Invalid credentials!
                        </div>";
                    }
                    if(isset($_GET['error']) AND $_GET['error'] == 'login'){
                        echo"<div class='alert alert-danger text-center' role='alert'>
                          Session expired, Please login to access the application!
                        </div>";
                    }
                ?>
                <div class="form-group">
                  <input type="text" class="form-control form-control-lg" name="username" placeholder="Username" required>
                </div>
                <div class="form-group">
                  <input type="password" class="form-control form-control-lg" name="password" placeholder="Password" required>
                </div>
                <div class="mt-3">
                  <button name="userLogin" class="btn btn-block btn-dark btn-lg font-weight-medium auth-form-btn">SIGN IN</button>
                </div>
                
                <br><br>
                <div class="text-center mt-2 font-weight-light">
                  Forgot password? <a href="recover.php" class="text-default">Recover</a>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
      <!-- content-wrapper ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->
  <!-- base:js -->
  <script src="../../vendors/js/vendor.bundle.base.js"></script>
  <!-- endinject -->
  <!-- inject:js -->
  <script src="../../js/off-canvas.js"></script>
  <script src="../../js/hoverable-collapse.js"></script>
  <script src="../../js/template.js"></script>
  <script src="../../js/settings.js"></script>
  <script src="../../js/todolist.js"></script>
  <!-- endinject -->
</body>

</html>
