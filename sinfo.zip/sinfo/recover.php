<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <!-- base:css -->
  <link rel="stylesheet" href="panel/vendors/typicons/typicons.css">
  <link rel="stylesheet" href="panel/vendors/css/vendor.bundle.base.css">
  <!-- endinject -->
  <!-- plugin css for this page -->
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="panel/css/vertical-layout-light/style.css">
  <!-- endinject -->
</head>

<body>
  <div class="container-scroller">
    <div class="container-fluid page-body-wrapper full-page-wrapper">
      <div class="content-wrapper d-flex align-items-center auth px-0">
        <div class="row w-100 mx-0">
          <div class="col-lg-4 mx-auto">
            <div class="auth-form-light text-left py-5 px-4 px-sm-5">
              <h4>Account Recovery</h4>
              <h6 class="font-weight-light">Enter your account related info.</h6>
              <form class="pt-3" method="POST" action="server.php">

                <?php
                    if(isset($_GET['data']) AND $_GET['data'] == 'recovered'){
                        echo"<div class='alert alert-success text-center' role='alert'>
                          Account password sent to your phone!
                        </div>";
                    }
                    if(isset($_GET['data']) AND $_GET['data'] == 'invalidphone'){
                        echo"<div class='alert alert-danger text-center' role='alert'>
                          Invalid phonenumber!
                        </div>";
                    }
                ?>
                
                <div class="form-group">
                  <input type="number" class="form-control form-control-lg" name="phone" placeholder="Phonenumber" required>
                </div>
                
                <div class="mt-3">
                  <button name="recoverPassword" class="btn btn-block btn-dark btn-lg font-weight-medium auth-form-btn">Recover</button>
                </div>
                
                <div class="text-center mt-4 font-weight-light">
                  Back to to <a href="login.php" class="text-default">Login</a>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
      <!-- content-wrapper ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->
  <!-- base:js -->
  <script src="../../vendors/js/vendor.bundle.base.js"></script>
  <!-- endinject -->
  <!-- inject:js -->
  <script src="../../js/off-canvas.js"></script>
  <script src="../../js/hoverable-collapse.js"></script>
  <script src="../../js/template.js"></script>
  <script src="../../js/settings.js"></script>
  <script src="../../js/todolist.js"></script>
  <!-- endinject -->
</body>

</html>
