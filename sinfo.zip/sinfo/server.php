<?php session_start();
include('connector.php');

if (isset($_POST['userLogin'])) {
	$username = $_POST['username'];
	$password = $_POST['password'];

	$query = mysqli_query($connect,"SELECT * FROM admin WHERE username='$username' AND password='$password'");
	$validation = mysqli_num_rows($query);

	if ($validation > 0) {

		$query = mysqli_query($connect,"SELECT * FROM admin WHERE username='$username' AND password='$password'");
		$row = mysqli_fetch_array($query);

		$_SESSION['dds_user'] = $row['id'];
		echo"<script>window.location='panel/';</script>";

	} else {

		$query = mysqli_query($connect,"SELECT * FROM students WHERE email = '$username' AND password = '$password'");
		$validation = mysqli_num_rows($query);

		if ($validation > 0) {

			$query = mysqli_query($connect,"SELECT * FROM students WHERE email = '$username' AND password = '$password'");
			$row = mysqli_fetch_array($query);

			$_SESSION['dds_user'] = $row['id'];
			echo"<script>window.location='panel/user.php';</script>";

		} else {
			echo"<script>window.location='login.php?error=invalid';</script>";
		}

	}
}

if (isset($_POST['addNewStudent'])) {

	$regno = $_POST['regno'];
	$name = $_POST['name'];
	$phone = $_POST['phone'];
	$email = $_POST['email'];
	$class = $_POST['class'];
	$password = $_POST['password'];

	$path = "images/";
	$path = $path . basename(time().".png");
	move_uploaded_file($_FILES['fileToUpload']['tmp_name'], $path);

	$query = mysqli_query($connect,"INSERT INTO students(regno, name, phone, email, class, password, image) VALUES ('$regno', '$name', '$phone', '$email', '$class', '$password', '$path')");

	// mista sms
	$curl = curl_init();

	curl_setopt_array($curl, array(
	  CURLOPT_URL => 'https://api.mista.io/sms',
	  CURLOPT_RETURNTRANSFER => true,
	  CURLOPT_ENCODING => '',
	  CURLOPT_MAXREDIRS => 10,
	  CURLOPT_TIMEOUT => 0,
	  CURLOPT_FOLLOWLOCATION => true,
	  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
	  CURLOPT_CUSTOMREQUEST => 'POST',
	  CURLOPT_POSTFIELDS => array('to' => "+25".$phone,'from' => 'SMS 250','unicode' => '0','sms' => "Hello ".$name."! Your student account have been created successfully. Use ".$email." as username and ".$password." as password. Thank you! from Seidol",'action' => 'send-sms'),
	  CURLOPT_HTTPHEADER => array(
	    'x-api-key: a02c7aaa-48a7-974d-901d-d6476d221271-152d9ab3'
	  ),
	));

	$response = curl_exec($curl);

	curl_close($curl);

	echo"<script>window.location='panel/companies.php?data=success';</script>";
}

if (isset($_GET['deleteUser'])) {
	$deleteUser = $_GET['deleteUser'];
	
	$query = mysqli_query($connect,"UPDATE users SET deleted = 1 WHERE id = '$deleteUser'");
	echo"<script>window.location='panel/users.php?data=deleted';</script>";
}

if (isset($_GET['deleteEmployee'])) {
	$deleteEmployee = $_GET['deleteEmployee'];
	
	$query = mysqli_query($connect,"UPDATE users SET deleted = 1 WHERE id = '$deleteEmployee'");
	echo"<script>window.location='panel/employees.php?data=deleted';</script>";
}

if (isset($_POST['editUser'])) {

	$id = $_POST['id'];
	$name = $_POST['name'];
	$phone = $_POST['phone'];
	$email = $_POST['email'];
	$address = $_POST['address'];
	
	$query = mysqli_query($connect,"UPDATE users SET name = '$name', phone = '$phone', email = '$email', address = '$address' WHERE id = '$id'");
	echo"<script>window.location='panel/users.php?data=updated';</script>";
}

if (isset($_POST['editEvent'])) {

	$id = $_POST['id'];
	$title = $_POST['title'];
	$description = $_POST['description'];
	$venue = $_POST['venue'];
	$sdate = $_POST['sdate'];
	$stime = $_POST['stime'];
	
	$query = mysqli_query($connect,"UPDATE events SET title = '$title', description = '$description', venue = '$venue', scheduredate = '$sdate', scheduretime = '$stime' WHERE id = '$id'");
	echo"<script>window.location='panel/events.php?data=updated';</script>";
}

if (isset($_POST['editEmployee'])) {

	$id = $_POST['id'];
	$name = $_POST['name'];
	$phone = $_POST['phone'];
	$email = $_POST['email'];
	$address = $_POST['address'];
	
	$query = mysqli_query($connect,"UPDATE users SET name = '$name', phone = '$phone', email = '$email', address = '$address' WHERE id = '$id'");
	echo"<script>window.location='panel/employees.php?data=updated';</script>";
}

if (isset($_POST['editCompany'])) {

	$id = $_POST['id'];
	$name = $_POST['name'];
	$phone = $_POST['phone'];
	$email = $_POST['email'];
	$class = $_POST['class'];
	
	$query = mysqli_query($connect,"UPDATE students SET name = '$name', phone = '$phone', email = '$email', class = '$class' WHERE id = '$id'");
	echo"<script>window.location='panel/companies.php?data=updated';</script>";
}

if (isset($_POST['editMarks'])) {

	$id = $_POST['id'];
	$course = $_POST['course'];
	$sem = $_POST['sem'];
	$value = $_POST['value'];
	
	$query = mysqli_query($connect,"UPDATE marks SET course = '$course', sem = '$sem', value = '$value' WHERE id = '$id'");
	echo"<script>window.location='panel/marks.php?data=updated';</script>";
}

if (isset($_POST['changePasswordAdmin'])) {
	$id = $_SESSION['dds_user'];
	$oldpassword = $_POST['oldpassword'];
	$newpassword = $_POST['newpassword'];

	$query = mysqli_query($connect,"SELECT * FROM admin WHERE id='$id' AND password='$oldpassword'");
	$validation = mysqli_num_rows($query);
	if ($validation > 0) {
		$query = mysqli_query($connect,"UPDATE admin SET password = '$newpassword' WHERE id = '$id'");
		echo"<script>window.location='panel/change_admin.php?data=changed';</script>";
	}else{
		echo"<script>window.location='panel/change_admin.php?data=wrong_old';</script>";
	}
}

if (isset($_POST['changePasswordCo'])) {
	$id = $_SESSION['dds_user'];
	$oldpassword = $_POST['oldpassword'];
	$newpassword = $_POST['newpassword'];

	$query = mysqli_query($connect,"SELECT * FROM students WHERE id='$id' AND password='$oldpassword'");
	$validation = mysqli_num_rows($query);
	if ($validation > 0) {
		$query = mysqli_query($connect,"UPDATE students SET password = '$newpassword' WHERE id = '$id'");
		echo"<script>window.location='panel/change_co.php?data=changed';</script>";
	}else{
		echo"<script>window.location='panel/change_co.php?data=wrong_old';</script>";
	}
}

if (isset($_POST['changePasswordU'])) {
	$id = $_SESSION['dds_user'];
	$oldpassword = $_POST['oldpassword'];
	$newpassword = $_POST['newpassword'];

	$query = mysqli_query($connect,"SELECT * FROM users WHERE id='$id' AND password='$oldpassword'");
	$validation = mysqli_num_rows($query);
	if ($validation > 0) {
		$query = mysqli_query($connect,"UPDATE users SET password = '$newpassword' WHERE id = '$id'");
		echo"<script>window.location='panel/change_u.php?data=changed';</script>";
	}else{
		echo"<script>window.location='panel/change_u.php?data=wrong_old';</script>";
	}
}

if (isset($_POST['addNewEvent'])) {
	$title = $_POST['title'];
	$description = $_POST['description'];
	$venue = $_POST['venue'];
	$sdate = $_POST['sdate'];
	$stime = $_POST['stime'];
	
	$query = mysqli_query($connect,"INSERT INTO events(title, description, venue, scheduredate, scheduretime) VALUES ('$title', '$description', '$venue', '$sdate', '$stime')");
	echo"<script>window.location='panel/events.php?data=success';</script>";
}

if (isset($_POST['addNewMark'])) {
	$student = $_POST['student'];
	$course = $_POST['course'];
	$sem = $_POST['sem'];
	$value = $_POST['value'];
	
	$query = mysqli_query($connect,"INSERT INTO marks(student, course, sem, value) VALUES ('$student', '$course', '$sem', '$value')");
	echo"<script>window.location='panel/marks.php?data=success';</script>";
}

if (isset($_GET['deleteCompany'])) {
	$deleteCompany = $_GET['deleteCompany'];
	
	$query = mysqli_query($connect,"UPDATE students SET deleted = 1 WHERE id = '$deleteCompany'");
	echo"<script>window.location='panel/companies.php?data=deleted';</script>";
}

if (isset($_GET['deleteMarks'])) {
	$deleteMarks = $_GET['deleteMarks'];
	
	$query = mysqli_query($connect,"UPDATE marks SET deleted = 1 WHERE id = '$deleteMarks'");
	echo"<script>window.location='panel/marks.php?data=deleted';</script>";
}

if (isset($_GET['deleteEvent'])) {
	$deleteEvent = $_GET['deleteEvent'];
	
	$query = mysqli_query($connect,"UPDATE events SET deleted = 1 WHERE id = '$deleteEvent'");
	echo"<script>window.location='panel/events.php?data=deleted';</script>";
}


if (isset($_POST['recoverPassword'])) {

	$phone = $_POST['phone'];

	$query = mysqli_query($connect,"SELECT * FROM users WHERE phone='$phone'");
	$validation = mysqli_num_rows($query);

	if ($validation > 0) {

		$query = mysqli_query($connect,"SELECT * FROM users WHERE phone='$phone'");
		$row = mysqli_fetch_array($query);

		// mista sms
		$curl = curl_init();

		curl_setopt_array($curl, array(
		  CURLOPT_URL => 'https://api.mista.io/sms',
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_ENCODING => '',
		  CURLOPT_MAXREDIRS => 10,
		  CURLOPT_TIMEOUT => 0,
		  CURLOPT_FOLLOWLOCATION => true,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => 'POST',
		  CURLOPT_POSTFIELDS => array('to' => "+25".$phone,'from' => 'SMS 250','unicode' => '0','sms' => "Hello ".$row['name']."! Your account have been recovered successfully. Use ".$row['email']." as username and ".$row['password']." as password. Thank you!",'action' => 'send-sms'),
		  CURLOPT_HTTPHEADER => array(
		    'x-api-key: a02c7aaa-48a7-974d-901d-d6476d221271-152d9ab3'
		  ),
		));

		$response = curl_exec($curl);

		curl_close($curl);

		echo"<script>window.location='recover.php?data=recovered';</script>";
	}else{
		echo"<script>window.location='recover.php?data=invalidphone';</script>";
	}

}

if (isset($_GET['newCardRequest'])) {

	$student = $_SESSION['dds_user'];
	$thisTime = time();

	$querys = mysqli_query($connect,"SELECT * FROM students WHERE id='$student'");
	$rows = mysqli_fetch_array($querys);

	// mista sms
	$curl = curl_init();

	curl_setopt_array($curl, array(
	  CURLOPT_URL => 'https://api.mista.io/sms',
	  CURLOPT_RETURNTRANSFER => true,
	  CURLOPT_ENCODING => '',
	  CURLOPT_MAXREDIRS => 10,
	  CURLOPT_TIMEOUT => 0,
	  CURLOPT_FOLLOWLOCATION => true,
	  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
	  CURLOPT_CUSTOMREQUEST => 'POST',
	  CURLOPT_POSTFIELDS => array('to' => "+25".$rows['phone'],'from' => 'SMS 250','unicode' => '0','sms' => "Hello ".$rows['name']."! Your card request have been sent successfully. Thank you!",'action' => 'send-sms'),
	  CURLOPT_HTTPHEADER => array(
	    'x-api-key: a02c7aaa-48a7-974d-901d-d6476d221271-152d9ab3'
	  ),
	));

	$response = curl_exec($curl);

	curl_close($curl);

	$amount = 100;
	$cphone = $rows['phone'];
	$cfullname = $rows['name'];

	//MoMo Pay

		$url = "https://pay.esicia.rw/";

		$curl = curl_init($url);
		curl_setopt($curl, CURLOPT_URL, $url);
		curl_setopt($curl, CURLOPT_POST, true);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

		$headers = array(
		   "Authorization: Basic ZXhhbWlyYTo3VG50OGc=",
		   "Content-Type: application/json",
		);
		curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);

		$paycode = rand(1000, 9999);
		$refid = time().$paycode;

		$data = <<<DATA
{
  "msisdn":"$cphone","details":"Subscription","refid":"$refid","amount":$amount,"currency":"RWF","email":"melchiroger@gmail.com","cname":"$cfullname","cnumber":"$cphone","pmethod":"momo","retailerid":"30","returl":"https://selvoger.com/sinfo/callback.php","redirecturl":"https://selvoger.com","bankid":"63510"
}
DATA;

		curl_setopt($curl, CURLOPT_POSTFIELDS, $data);

		//for debug only!
		curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);

		$resp = curl_exec($curl);
		curl_close($curl);

	mysqli_query($connect,"INSERT INTO requests(student, rdatetime, refid) VALUES('$student', '$thisTime', '$refid')");

	echo"<script>window.location='panel/cardrequests.php?data=recovered';</script>";

}

?>