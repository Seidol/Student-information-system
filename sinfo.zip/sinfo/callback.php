<?php 
    include('connector.php');

    // Takes raw data from the request
    $json = file_get_contents('php://input');

    // Converts it into a PHP object
    $data = json_decode($json,TRUE);
    if($data['statusid']=="01"){
        $dateop = time();
        $accExpDate = $dateop + (86400 * 2);
        mysqli_query($connect, "UPDATE requests SET status = 1 WHERE refid = '".$data['refid']."'");
    }
?>