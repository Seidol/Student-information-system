<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">	
</head>
<body>
	<center>
		<img src="image.jpg" style="width: 200px; margin-top: 50px;">
		<br><br><br>
		<h3 style="width: 250px; line-height: 25px; font-family: arial;"><span style="font-size: 20px; color: #1a75bc;">STUDENT ID CARD</span><br>QR CODE GENERATION SYSTEM</h3>
		<div style="width: 100%;">
			<center>
				<img src="qrcode.png" style="width: 100px;">
			</center>
		</div>
		<img src="loading.gif" style="border-radius: 50%; width: 70px; margin-top: 20px;">
	</center>
</body>
<script type="text/javascript">
	var redirectToHome = function(){
		window.location = 'login.php';
	}
	setInterval(redirectToHome, 10000);
</script>
</html>